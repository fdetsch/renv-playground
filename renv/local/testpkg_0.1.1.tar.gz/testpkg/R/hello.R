#' Hello, World!
#'
#' @description
#' Hello, world!
#'
#' @param whom Whom to say hello.
#'
#' @examples
#' hello()
#'
#' @export
#' @name hello
hello = function(whom = "world") {
  sprintf(
    "Hello, %s!"
    , whom
  )
}
